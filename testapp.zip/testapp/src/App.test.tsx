import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';

test('renders app', () => {
  render(<App />);
  expect(screen.getByText(/EDITOR PICK/i)).toBeInTheDocument();
  expect(screen.getByText(/For Families of Teens at Microsoft Surface/i)).toBeInTheDocument();
  // Ajoutez d'autres vérifications pour les éléments attendus
});