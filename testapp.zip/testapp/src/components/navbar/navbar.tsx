import React from 'react';
import logo from './site-logo.svg'; 
import image1 from './tech-news-post-featured-img-01.jpg'; 
import image2 from './tech-news-post-featured-img-09.jpg';

const Navbar = () => {
  return (
    <div className="bg-washed-white p-4 text-center">
      <nav className="flex items-center justify-between">
        <div className="flex items-center space-x-4" style={{ marginLeft: '10rem', position: 'relative', top: '-55px' }}> {/* Déplacer vers la droite en ajoutant un style inline */}
          <img src={logo} alt="logo" style={{ height: '170px', width: '170px' }} /> {/* Taille personnalisée pour l'image */}
          <div className="flex items-center space-x-4">
            <span className="text-black" style={{ fontSize: '17px',fontWeight: '600'}}>TECHNOLOGY</span> {/* Taille personnalisée pour le texte */}
            <span className="text-black" style={{ fontSize: '17px',fontWeight: '600' }}>GADGET</span>
            <span className="text-black" style={{ fontSize: '17px',fontWeight: '600' }}>SOFTWARE</span>
            <span className="text-black" style={{ fontSize: '17px',fontWeight: '600' }}>APPS</span>
            <span className="text-black" style={{ fontSize: '17px',fontWeight: '600' }}>GAMES</span>
            <span className="text-black" style={{ fontSize: '17px',fontWeight: '600' }}>PODCASTS</span>
          </div>
        </div>
        <div className="flex items-center space-x-4" style={{ marginRight: '7rem', position: 'relative', top: '-55px' }}> {/* Déplacer vers la gauche en ajoutant un style inline */}
         <span className="text-purple" style={{ fontSize: '17px', color: '#805ADE', fontWeight: '600' }}>Subscribe</span> {/* Taille personnalisée pour le texte */}
          <span className="text-black" style={{ fontSize: '17px', fontWeight: '600' }}>Sign In</span>
          <i className="fas fa-search text-black" style={{ fontSize: '20px' }}></i>  {/* Taille personnalisée pour l'icône */}
        </div>
      </nav>
      
      
    
    <div className="mt-2" style={{ position: 'relative' }}>
    <div style={{ position: 'relative', width: '55%', marginLeft: '11rem', top:'-85px' }}>
        <img src={image1} alt="image1" style={{ width: '100%', position: 'relative' }} />
        <p className="text-white" style={{ fontSize: '18px', fontWeight: '500', position: 'absolute', top: '55%', left: '15%', transform: 'translate(-50%, -50%)', zIndex: '1' }}>SOFTWARE</p>
        <p className="text-white" style={{ fontSize: '30px', fontWeight: '700', position: 'absolute', top: '65%', left: '36%', transform: 'translate(-50%, -50%)', zIndex: '1' }}>Running macOS and Windows 10</p>
        <div className="flex items-center space-x-2" style={{ position: 'absolute', top: '70%', left: '29%', transform: 'translateX(-50%)', zIndex: '1' }}>
            <i className="fas fa-user text-white" style={{ fontSize: '16px' }}></i>
            <span className="text-white" style={{ fontSize: '16px' }}> akbarh</span>
            <i className="far fa-calendar-alt text-white" style={{ fontSize: '16px' }}></i>
            <span className="text-white" style={{ fontSize: '16px' }}>July 18, 2022</span>
            <i className="far fa-comment text-white" style={{ fontSize: '16px' }}></i>
            <span className="text-white" style={{ fontSize: '16px' }}>25 Comments</span>
        </div>
        <div style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', backgroundColor: 'rgba(0, 0, 0, 0.5)', zIndex: '0' }}></div>
        <p className="text-white" style={{ fontSize: '16px', position: 'absolute', top: '85%', left: '38%', transform: 'translate(-50%, -50%)', zIndex: '1' }}>Cursus iaculis etiam in In nullam donec sem sed consequat scelerisque<br />   nibh amet, massa egestas risus, gravida vel amet, imperdiet ...</p>
    </div>
  </div>

   <div className="mt-2" style={{ position: 'relative' }}>
    <div style={{ position: 'relative', width: '55%', marginLeft: '67rem', top:'-614px' }}>
        <img src={image2} alt="image2" style={{ width: '35%', position: 'relative' }} />
        <p className="text-white" style={{ fontSize: '15px', position: 'absolute', top: '90%', color: '#805ADE', left: '3%', transform: 'translate(-50%, -50%)', zIndex: '1' }}>APPS</p>
        <p className="text-black" style={{ fontSize: '18px', fontWeight: '700', position: 'absolute', top: '105%', left: '15%', transform: 'translate(-50%, -50%)', zIndex: '1' }}>Broke a Glass? Someday You <br />Might 3-D-Print a New One</p><br />
        <p className="text-white" style={{ fontSize: '15px', position: 'absolute', top: '128%', color: '#805ADE', left: '4%', transform: 'translate(-50%, -50%)', zIndex: '1' }}>GAMES</p>
        <p className="text-black" style={{ fontSize: '18px', fontWeight: '700', position: 'absolute', top: '143%', left: '18%', transform: 'translate(-50%, -50%)', zIndex: '1' }}>This Is a Giant Shipworm. You May <br />Wish It Had Stayed In Its Tube.</p><br />
        <p className="text-white" style={{ fontSize: '15px', position: 'absolute', top: '166%', color: '#805ADE', left: '6%', transform: 'translate(-50%, -50%)', zIndex: '1' }}>EDITOR PICK</p>
        <p className="text-black" style={{ fontSize: '18px', fontWeight: '700', position: 'absolute', top: '176%', left: '18%', transform: 'translate(-50%, -50%)', zIndex: '1' }}>For Families of Teens at Microsoft </p><br />
        <p className="text-white" style={{ fontSize: '15px', position: 'absolute', top: '195%', color: '#805ADE', left: '6%', transform: 'translate(-50%, -50%)', zIndex: '1' }}>EDITOR PICK</p>
        <p className="text-black" style={{ fontSize: '18px', fontWeight: '700', position: 'absolute', top: '203%', left: '18%', transform: 'translate(-50%, -50%)', zIndex: '1' }}>Why Netflix shares are down 10% </p>
        </div>
  </div>
    </div>
  );
};

export default Navbar;