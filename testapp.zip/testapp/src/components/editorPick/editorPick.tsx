import React from 'react';
import image3 from './tech-news-post-featured-img-02.jpg';
import image4 from './tech-news-post-featured-img-10.jpg';
import image5 from './tech-news-post-featured-img-21.jpg';

interface EditorPickProps {
  title: string;
  text: string;
  image: string;
}

const EditorPick: React.FC<EditorPickProps> = ({ title, text, image }) => {
  return (
    
      <div style={{ display: 'flex', flexDirection: 'row', marginTop: '-900px', marginRight: '100px' }}>
        <div>
          <div style={{ position: 'relative' }}>
            <img src={image} alt="" style={{ width: '120%', position: 'relative', top: '-25px', left: '-157%' }} />
            <h2 style={{
              fontSize: '12px',
              position: 'absolute',
              top: '-10%',
              left: '-145%',
              backgroundColor: 'white',
              color: 'black',
              borderRadius: '2px',
              fontWeight: '600',
            }}>
              {title}
            </h2>
          </div>
          <p style={{ fontSize: '16px', bottom: '15px', position: 'relative', left: '-154%', fontWeight: '700' }}>{text}</p>
        </div>
        <hr className="my-4 border-gray-300" />
      </div>
    
     
    
  );
};

export default EditorPick;


