// newletters1.tsx
import React from 'react';

const Newletters = () => {
  return (
    <div className="bg-white rounded-lg shadow-md p-4 mb-4 border border-gray-300" style={{ width: '300px', height: '370px',borderRadius: '4px',top: '-940px', position: 'relative', left: '71%'}}>
      <div className="flex items-center mb-4">
      <span style={{ color: 'white', backgroundColor: '#805ADE',padding: '12px',marginTop: '-16px' }} className="elementor-icon elementor-animation-">
        <i  style={{ fontSize: '20px' }}aria-hidden="true" className="far fa-envelope"></i>
      </span>
      </div>
      <p style={{ fontSize: '26px' }} className="text-lg font-bold mb-4">Subscribe to Our Newsletter</p>
      <p style={{ fontSize: '19px' }}className="text-gray-600 mb-4">gravida aliquet vulputate faucibus tristique odio.</p>
      <div className="mb-4">
        <input
        style={{borderRadius: '4px'}}
          type="email"
          id="email"
          className="block w-full p-2 border border-gray-300 rounded-lg"
          placeholder="Email address"
          required
        />
      </div>
      <button
        type="submit"
        name="wpforms[submit]"
        id="wpforms-submit-1002"
        className="wpforms-submit"
        data-alt-text="Sending..."
        data-submit-text="Subscribe"
        aria-live="assertive"
        value="wpforms-submit"
        style={{ backgroundColor: '#805ADE', color: 'white', fontWeight: '700', border: 'none', padding: '10px 20px', borderRadius: '20px', cursor: 'pointer' }}
      >
        Subscribe
      </button>
    </div>
  );
};

export default Newletters;














 
