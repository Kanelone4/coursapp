// App.tsx
import React from 'react';
import logo from './logo.svg';
import Navbar from './components/navbar/navbar';
import EditorPick from './components/editorPick/editorPick';
import Newletters from './components/newletters1/newletters1';
import img3 from './components/editorPick/tech-news-post-featured-img-02.jpg';
import img4 from './components/editorPick/tech-news-post-featured-img-10.jpg';
import img5 from './components/editorPick/tech-news-post-featured-img-21.jpg';

const editorPicks = [
  { title: 'EDITOR PICK', text: 'For Families of Teens at Microsoft ', image: img3 },
  { title: 'EDITOR PICK', text: 'Why Netflix shares are down 10%', image: img4 },
  { title: 'APPS', text: '6 Bots That Deliver Science ', image: img5 }
];


const App: React.FC = () => {
  return (
    <div>
      <Navbar />
      <div>
        <h1 style={{ fontSize: '20px', top: '-240px', position: 'relative', left: '13%', fontWeight: '700' }}>Editor's Pick</h1>
      </div>
      <hr style={{ position: 'relative', top: '100px', left: '13%',width:'44%' }} className="my-4 border-gray-300 w-2/5" />
      <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: '1px', margin: '280px', padding: '40px' }}>
        <span style={{ display: 'flex', alignItems: 'center', color: '#805ADE',fontWeight:'500' }}>
          <span style={{ fontSize: '18px', fontWeight: '600', whiteSpace: 'nowrap', letterSpacing: '1px',top: '-586px', position: 'relative', left: '410%' }}>View All</span>
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2048 2048" style={{ width: '20px', height: '20px', marginLeft: '10px', fill: '#805ADE',top: '-586px', position: 'relative', left: '410%' }}>
            <path d="M6.125 1088h1797.89l-402.976 403 89.994 90L2048 1024l-556.966-557-89.994 90 402.976 403H6.125v128z"></path>
          </svg>
        </span>
        {editorPicks.map((editorPick, index) => (
          <EditorPick key={index} title={editorPick.title} text={editorPick.text} image={editorPick.image} />
        ))}
      </div>
     
      <div>
        <Newletters />
      </div>
      
    </div>
     
  );
};

export default App;